
import React, { useState } from 'react';
import { AuthMode, UserProfile } from '../types';
import { SignInForm } from './SignInForm';
import { SignUpForm } from './SignUpForm';
import { ForgotPasswordForm } from './ForgotPasswordForm';

interface AuthContainerProps {
  onAuthSuccess: (user: UserProfile) => void;
}

export const AuthContainer: React.FC<AuthContainerProps> = ({ onAuthSuccess }) => {
  const [mode, setMode] = useState<AuthMode>('signin');

  return (
    <div className="min-h-screen flex bg-slate-100">
      {/* Left Panel: Hero/Industrial Branding */}
      <div className="hidden lg:flex w-1/2 bg-slate-900 relative overflow-hidden items-center justify-center p-12">
        <div className="absolute inset-0 opacity-20 pointer-events-none">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse">
              <path d="M 10 0 L 0 0 0 10" fill="none" stroke="white" strokeWidth="0.1" />
            </pattern>
            <rect width="100" height="100" fill="url(#grid)" />
          </svg>
        </div>
        
        <div className="relative z-10 text-white max-w-lg">
          <div className="flex items-center space-x-3 mb-8">
            <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
            </div>
            <h1 className="brand-font text-3xl font-bold tracking-tighter">MECHHIRE PRO</h1>
          </div>
          <h2 className="text-4xl font-extrabold mb-6 leading-tight">Empowering the Future of Mechanical Engineering.</h2>
          <p className="text-slate-400 text-lg mb-8">
            The specialized portal for skilled technicians, engineers, and mechanical specialists to find their next challenge in elite industries.
          </p>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 bg-slate-800/50 rounded-xl border border-slate-700">
              <div className="text-blue-500 font-bold text-2xl">500+</div>
              <div className="text-slate-400 text-sm">Industrial Partners</div>
            </div>
            <div className="p-4 bg-slate-800/50 rounded-xl border border-slate-700">
              <div className="text-blue-500 font-bold text-2xl">12k</div>
              <div className="text-slate-400 text-sm">Active Professionals</div>
            </div>
          </div>
        </div>
      </div>

      {/* Right Panel: Forms */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-6 sm:p-12">
        <div className="w-full max-w-md">
          <div className="mb-8 text-center lg:text-left">
            <div className="lg:hidden flex justify-center mb-6">
               <div className="w-10 h-10 bg-blue-600 rounded flex items-center justify-center text-white">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                </svg>
              </div>
            </div>
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
              {mode === 'signin' && 'Sign in to your account'}
              {mode === 'signup' && 'Join the organization'}
              {mode === 'forgot-password' && 'Recover account access'}
            </h1>
            <p className="text-slate-500 mt-2">
              {mode === 'signin' && "Access your mechanical professional profile."}
              {mode === 'signup' && "Create your account to browse specialized roles."}
              {mode === 'forgot-password' && "We'll help you get back to your dashboard."}
            </p>
          </div>

          <div className="bg-white p-8 rounded-2xl shadow-xl border border-slate-200">
            {mode === 'signin' && (
              <SignInForm 
                onSuccess={onAuthSuccess} 
                onSignUpClick={() => setMode('signup')} 
                onForgotClick={() => setMode('forgot-password')} 
              />
            )}
            {mode === 'signup' && (
              <SignUpForm 
                onSuccess={onAuthSuccess} 
                onSignInClick={() => setMode('signin')} 
              />
            )}
            {mode === 'forgot-password' && (
              <ForgotPasswordForm 
                onBack={() => setMode('signin')} 
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
