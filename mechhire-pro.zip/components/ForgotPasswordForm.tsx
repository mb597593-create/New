
import React, { useState } from 'react';

interface ForgotPasswordFormProps {
  onBack: () => void;
}

export const ForgotPasswordForm: React.FC<ForgotPasswordFormProps> = ({ onBack }) => {
  const [method, setMethod] = useState<'email' | 'phone'>('email');
  const [inputValue, setInputValue] = useState('');
  const [isSent, setIsSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate API call to send recovery link
    setIsSent(true);
  };

  if (isSent) {
    return (
      <div className="text-center py-6">
        <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
        </div>
        <h3 className="text-xl font-bold text-slate-900 mb-2">Recovery Sent!</h3>
        <p className="text-slate-600 mb-6">
          We've sent a recovery link to your {method === 'email' ? 'email address' : 'phone number'}.
        </p>
        <button 
          onClick={onBack}
          className="w-full py-3 bg-blue-600 text-white rounded-lg font-bold hover:bg-blue-700 transition"
        >
          Back to Login
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="flex bg-slate-100 p-1 rounded-lg">
        <button 
          type="button"
          onClick={() => { setMethod('email'); setInputValue(''); }}
          className={`flex-1 py-2 text-sm font-medium rounded-md transition ${method === 'email' ? 'bg-white shadow text-blue-600' : 'text-slate-500'}`}
        >
          Email
        </button>
        <button 
          type="button"
          onClick={() => { setMethod('phone'); setInputValue(''); }}
          className={`flex-1 py-2 text-sm font-medium rounded-md transition ${method === 'phone' ? 'bg-white shadow text-blue-600' : 'text-slate-500'}`}
        >
          Phone
        </button>
      </div>

      <div>
        <label className="block text-sm font-medium text-slate-700 mb-2">
          {method === 'email' ? 'Enter registered Email' : 'Enter registered Phone'}
        </label>
        <input 
          type={method === 'email' ? 'email' : 'tel'}
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-blue-500 outline-none" 
          placeholder={method === 'email' ? 'name@domain.com' : '+1 000 000 0000'}
          required
        />
      </div>

      <button 
        type="submit"
        className="w-full py-3 bg-blue-600 text-white rounded-lg font-bold hover:bg-blue-700 transition shadow-lg shadow-blue-500/20"
      >
        Send Recovery Code
      </button>

      <button 
        type="button"
        onClick={onBack}
        className="w-full text-sm font-semibold text-slate-500 hover:text-slate-700 transition"
      >
        Return to Sign In
      </button>
    </form>
  );
};
