
import React, { useState } from 'react';
import { UserProfile } from '../types';

interface SignUpFormProps {
  onSuccess: (user: UserProfile) => void;
  onSignInClick: () => void;
}

export const SignUpForm: React.FC<SignUpFormProps> = ({ onSuccess, onSignInClick }) => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    phone: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const [error, setError] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (Object.values(formData).some(val => val === '')) {
      setError('All fields are required');
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }

    // Mock successful signup
    onSuccess({
      firstName: formData.firstName,
      lastName: formData.lastName,
      email: formData.email,
      phone: formData.phone
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {error && (
        <div className="p-3 bg-red-50 text-red-600 text-sm rounded-lg border border-red-200 animate-pulse">
          {error}
        </div>
      )}
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-xs font-bold text-slate-500 uppercase mb-1">First Name</label>
          <input 
            name="firstName"
            type="text" 
            value={formData.firstName}
            onChange={handleChange}
            className="w-full px-3 py-2 rounded border border-slate-300 focus:ring-2 focus:ring-blue-500 outline-none" 
            placeholder="e.g. Robert"
            required
          />
        </div>
        <div>
          <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Last Name</label>
          <input 
            name="lastName"
            type="text" 
            value={formData.lastName}
            onChange={handleChange}
            className="w-full px-3 py-2 rounded border border-slate-300 focus:ring-2 focus:ring-blue-500 outline-none" 
            placeholder="e.g. Miller"
            required
          />
        </div>
      </div>

      <div>
        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Phone Number</label>
        <input 
          name="phone"
          type="tel" 
          value={formData.phone}
          onChange={handleChange}
          className="w-full px-3 py-2 rounded border border-slate-300 focus:ring-2 focus:ring-blue-500 outline-none" 
          placeholder="+1 (555) 000-0000"
          required
        />
      </div>

      <div>
        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Professional Email</label>
        <input 
          name="email"
          type="email" 
          value={formData.email}
          onChange={handleChange}
          className="w-full px-3 py-2 rounded border border-slate-300 focus:ring-2 focus:ring-blue-500 outline-none" 
          placeholder="robert@example.com"
          required
        />
      </div>

      <div>
        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Password</label>
        <input 
          name="password"
          type="password" 
          value={formData.password}
          onChange={handleChange}
          className="w-full px-3 py-2 rounded border border-slate-300 focus:ring-2 focus:ring-blue-500 outline-none" 
          placeholder="••••••••"
          required
        />
      </div>

      <div>
        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Re-type Password</label>
        <input 
          name="confirmPassword"
          type="password" 
          value={formData.confirmPassword}
          onChange={handleChange}
          className="w-full px-3 py-2 rounded border border-slate-300 focus:ring-2 focus:ring-blue-500 outline-none" 
          placeholder="••••••••"
          required
        />
      </div>

      <button 
        type="submit"
        className="w-full py-3 bg-slate-900 text-white rounded-lg font-bold hover:bg-slate-800 transition transform active:scale-[0.98] shadow-lg mt-2"
      >
        Create Account
      </button>

      <div className="text-center mt-4">
        <button 
          type="button"
          onClick={onSignInClick}
          className="text-sm text-slate-500 hover:text-blue-600 transition"
        >
          Already have an account? <span className="font-bold">Sign In</span>
        </button>
      </div>
    </form>
  );
};
