
import React from 'react';
import { UserProfile } from '../types';

interface DashboardProps {
  user: UserProfile;
  onLogout: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ user, onLogout }) => {
  return (
    <div className="min-h-screen bg-slate-50">
      {/* Top Header */}
      <header className="bg-slate-900 text-white py-4 px-6 md:px-12 flex justify-between items-center shadow-lg">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clipRule="evenodd" />
            </svg>
          </div>
          <span className="brand-font font-bold tracking-tight text-xl">MECHHIRE</span>
        </div>
        <div className="flex items-center space-x-4">
          <span className="hidden sm:block text-slate-400 text-sm">Industrial Network Status: <span className="text-green-500">Online</span></span>
          <button 
            onClick={onLogout}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 rounded text-sm font-bold transition"
          >
            Logout
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto py-10 px-6 md:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Profile Card */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
              <div className="h-24 bg-gradient-to-r from-blue-600 to-indigo-700"></div>
              <div className="px-6 pb-6 text-center">
                <div className="relative -mt-12 mb-4">
                  <div className="w-24 h-24 bg-white rounded-full p-1 mx-auto shadow-md">
                    <div className="w-full h-full bg-slate-100 rounded-full flex items-center justify-center text-slate-400">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
                      </svg>
                    </div>
                  </div>
                </div>
                <h2 className="text-2xl font-bold text-slate-900">{user.firstName} {user.lastName}</h2>
                <p className="text-blue-600 font-medium mb-4">Mechanical Specialist</p>
                <div className="flex flex-col space-y-2 text-sm text-slate-500 text-left border-t border-slate-100 pt-4">
                  <div className="flex items-center">
                    <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
                    {user.email}
                  </div>
                  <div className="flex items-center">
                    <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
                    {user.phone}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Job Feed / Skillset */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
              <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center">
                <span className="w-2 h-6 bg-blue-600 rounded mr-3"></span>
                Mechanical Skill Set
              </h3>
              <div className="flex flex-wrap gap-2">
                {['CNC Machining', 'CAD/CAM', 'Hydraulics', 'Pneumatics', 'Welding', 'Robotics'].map(skill => (
                  <span key={skill} className="px-3 py-1 bg-slate-100 text-slate-700 rounded-full text-sm font-medium border border-slate-200">
                    {skill}
                  </span>
                ))}
                <button className="px-3 py-1 bg-blue-50 text-blue-600 rounded-full text-sm font-bold hover:bg-blue-100 transition">
                  + Add Skill
                </button>
              </div>
            </div>

            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-bold text-slate-900">Recommended Opportunities</h3>
                <button className="text-sm font-bold text-blue-600">View All</button>
              </div>
              <div className="space-y-4">
                {[
                  { title: 'Senior HVAC Engineer', company: 'Thermal Dynamics Corp', location: 'Chicago, IL', pay: '$95k - $120k' },
                  { title: 'Hydraulic Systems Specialist', company: 'Heavy Mach Industrial', location: 'Houston, TX', pay: '$80k - $105k' },
                  { title: 'Mechanical Design Lead', company: 'Precision Gears Ltd', location: 'Remote', pay: '$110k - $140k' },
                ].map((job, idx) => (
                  <div key={idx} className="p-4 border border-slate-100 rounded-xl hover:border-blue-200 hover:bg-blue-50/30 transition cursor-pointer">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-bold text-slate-900">{job.title}</h4>
                        <p className="text-sm text-slate-500">{job.company} • {job.location}</p>
                      </div>
                      <span className="text-xs font-bold px-2 py-1 bg-green-100 text-green-700 rounded uppercase tracking-wider">
                        New
                      </span>
                    </div>
                    <div className="mt-2 text-sm font-semibold text-blue-600">{job.pay}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};
