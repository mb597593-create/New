
import React, { useState } from 'react';
import { UserProfile } from '../types';

interface SignInFormProps {
  onSuccess: (user: UserProfile) => void;
  onSignUpClick: () => void;
  onForgotClick: () => void;
}

export const SignInForm: React.FC<SignInFormProps> = ({ onSuccess, onSignUpClick, onForgotClick }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email && password) {
      // Mock validation
      onSuccess({
        firstName: 'John',
        lastName: 'Mechanic',
        email: email,
        phone: '+1 234 567 8901'
      });
    } else {
      setError('Please fill in all fields');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      {error && (
        <div className="p-3 bg-red-50 text-red-600 text-sm rounded-lg border border-red-200">
          {error}
        </div>
      )}
      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1">Professional Email</label>
        <input 
          type="email" 
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition outline-none" 
          placeholder="name@company.com"
          required
        />
      </div>
      <div>
        <div className="flex justify-between items-center mb-1">
          <label className="text-sm font-medium text-slate-700">Password</label>
          <button 
            type="button"
            onClick={onForgotClick}
            className="text-xs font-semibold text-blue-600 hover:text-blue-700"
          >
            Forgot?
          </button>
        </div>
        <input 
          type="password" 
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition outline-none" 
          placeholder="••••••••"
          required
        />
      </div>
      <button 
        type="submit"
        className="w-full py-3 bg-blue-600 text-white rounded-lg font-bold hover:bg-blue-700 transition transform active:scale-[0.98] shadow-lg shadow-blue-500/30"
      >
        Sign In
      </button>
      <div className="text-center mt-6">
        <span className="text-sm text-slate-500">New to the organization? </span>
        <button 
          type="button"
          onClick={onSignUpClick}
          className="text-sm font-bold text-blue-600 hover:underline"
        >
          Create an account
        </button>
      </div>
    </form>
  );
};
