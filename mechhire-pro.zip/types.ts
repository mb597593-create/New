
export type AuthMode = 'signin' | 'signup' | 'forgot-password' | 'recovery-sent';

export interface UserProfile {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  mechanicalSkill?: string;
}

export interface AuthState {
  user: UserProfile | null;
  token: string | null;
  loading: boolean;
  error: string | null;
}
