
import React, { useState } from 'react';
import { AuthMode, UserProfile } from './types';
import { AuthContainer } from './components/AuthContainer';
import { Dashboard } from './components/Dashboard';

const App: React.FC = () => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleAuthSuccess = (userData: UserProfile) => {
    setIsLoading(true);
    // Simulate API delay
    setTimeout(() => {
      setUser(userData);
      setIsLoading(false);
    }, 1000);
  };

  const handleLogout = () => {
    setUser(null);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="flex flex-col items-center">
          <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
          <p className="mt-4 text-slate-400 brand-font tracking-widest animate-pulse">SYNCHRONIZING...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen font-sans">
      {user ? (
        <Dashboard user={user} onLogout={handleLogout} />
      ) : (
        <AuthContainer onAuthSuccess={handleAuthSuccess} />
      )}
    </div>
  );
};

export default App;
