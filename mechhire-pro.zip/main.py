
from fastapi import FastAPI, HTTPException, Depends, status
from pydantic import BaseModel, EmailStr
from typing import Optional, List
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="MechHire Pro API")

# Setup CORS for the frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Models
class UserSignUp(BaseModel):
    firstName: str
    lastName: str
    phone: str
    email: EmailStr
    password: str
    confirmPassword: str

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserProfile(BaseModel):
    firstName: str
    lastName: str
    email: EmailStr
    phone: str

class RecoveryRequest(BaseModel):
    method: str  # 'email' or 'phone'
    value: str

# Mock Database
users_db = []

@app.post("/api/signup", status_code=status.HTTP_201_CREATED)
async def signup(user: UserSignUp):
    if user.password != user.confirmPassword:
        raise HTTPException(status_code=400, detail="Passwords do not match")
    
    # Check if user already exists
    if any(u['email'] == user.email for u in users_db):
        raise HTTPException(status_code=400, detail="Email already registered")
    
    user_data = user.dict()
    users_db.append(user_data)
    
    return {"message": "User created successfully", "user": UserProfile(**user_data)}

@app.post("/api/signin")
async def signin(credentials: UserLogin):
    user = next((u for u in users_db if u['email'] == credentials.email), None)
    
    if not user or user['password'] != credentials.password:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password"
        )
    
    return {"message": "Login successful", "user": UserProfile(**user)}

@app.post("/api/forgot-password")
async def forgot_password(request: RecoveryRequest):
    # Logic to find user by email or phone and send code
    return {"message": f"Recovery code sent via {request.method}"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
